package com.example.exampractice;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class StudentActivity extends AppCompatActivity {

    TextView textViewWelcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        Intent i = getIntent();
        String userName = i.getStringExtra("userName");

        Intent intent = new Intent(StudentActivity.this,Messages.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(StudentActivity.this,0,intent,0);
        Notification notification = new Notification.Builder(StudentActivity.this)
                                                    .setTicker("Ticker title").setContentTitle("Content title").setContentText("Message").setContentIntent(pendingIntent)

        textViewWelcome= (TextView)findViewById(R.id.textViewStudentWelcome);

        textViewWelcome.setText("Welcome "+userName);
    }
}
